GAE Wiki
========

This is a simple wiki engine for Google App Engine.


Contributors
============

See gaewiki/AUTHORS


License
=======

The wiki itself is distributed under GNU GPL v3.

pytz is distributed under the MIT license.
